#Program:     testCoin.py
#Purpose:     Test the Coin class
#Author:      Adelaida Medlock
#Date:        January 9, 2019

# input the coin module so we can use the Coin class
import coin

# create an object from the Coin class
myCoin = coin.Coin()
    
# display the side of the coin that is facing up
print('This side is up:', myCoin.get_sideup())
    
# toss the coin
print('I am tossing the coin...')
myCoin.toss()
    
# display the side of the coin that is facing up
print('This side is up:', myCoin.get_sideup())
