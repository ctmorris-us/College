import pygame
import abc

class Drawable(metaclass = abc.ABCMeta):
	def __init__(self,x,y):
		self.__x = x
		self.__y = y
	
	def setLocation(self,x,y):
		self.__x = x
		self.__y = y
	
	def getX(self):
		return self.__x
	
	def getY(self):
		return self.__y
		
	@abc.abstractmethod
	def draw(self,surface):
		pass

class House(Drawable):
	def __init__(self,x,y,width,color = (255,0,0)):
		super().__init__(x,y)
		self.__width = width
		self.__color = color
	
	
	def draw(self,surface):
		pygame.draw.rect(surface,self.__color, (self.getX(), self.getY(), self.__width, self.__width))

pygame.init()

surface = pygame.display.set_mode((400,300))


objects = [];
objects.append(House(100,100, 30))
objects.append(House(200,200, 10))


clock = pygame.time.Clock()

while True:
	surface.fill((255,255,255))
	for event in pygame.event.get():
		if (event.type == pygame.QUIT) or (event.type == pygame.KEYDOWN and event.__dict__['key'] == pygame.K_q):
			pygame.quit()
			exit()
		elif(event.type == pygame.MOUSEBUTTONDOWN):
			loc = event.__dict__['pos']
			objects.append(House(loc[0], loc[1], 50, (0,0,255)))
	
	objects[0].setLocation(objects[0].getX()+1, objects[0].getY())
	if objects[0].getX() > 400:
		objects[0].setLocation(0, objects[0].getY())
		
	for o in objects:
		o.draw(surface)
	
	pygame.display.update()
	clock.tick(30)