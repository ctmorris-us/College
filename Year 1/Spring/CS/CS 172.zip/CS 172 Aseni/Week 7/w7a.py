class Node():
	def __init__(self,data,next = None):
		self.__data = data
		self.__next = next
	
	def __str__(self):
		return str(self.__data)
	
	def getNext(self):
		return self.__next
	
	def setNext(self,next):
		self.__next = next
	
	def getData(self):
		return self.__data
		
class LinkedList():
	def __init__(self):
		self.__head = None
	
	def append(self,data):
		temp1 = Node(data)
		if self.__head == None:
			self.__head = temp1
		else:
			temp = self.__head
			while temp.getNext() != None:
				temp = temp.getNext()
			
			temp.setNext(temp1)
		
	
	def __str__(self):
		temp = self.__head
		mystr = ''
		while temp != None:
			mystr += str(temp) + '->'
			temp  = temp.getNext()
		
		mystr += 'None'
		return mystr
	
	def __len__(self):
		temp = self.__head
		if self.__head == None:
			return 0
		
		count = 1
		while temp.getNext() != None:
			temp = temp.getNext()
			count += 1
		
		return count
			
	
	def __getitem__(self,index):
		if index >= len(self):
			print('Index out of bounds')
			return None
		
		temp = self.__head
		for i in range(index):
			temp = temp.getNext()
		
		return temp.getData()

if __name__ == "__main__":
	a = Node('hello')
	b = Node([2,3,4,5,7])
	c = Node(4.234)
	
	a.setNext(b)
	b.setNext(c)
	
	temp = a
	while temp != None:
		#print(temp)
		temp = temp.getNext()

	myll = LinkedList()
	myll.append('hello')
	print(myll)
	
	myll.append(4)
	myll.append([3,3,0])
	print(myll)
	
	print(len(myll))


	d = myll[2234234235]  #myll.__getitem__(2)
	print(d)

